document.addEventListener('keypress', (event) => {
  var key = event.key;

  if (key == 'r') {
    document.getElementById('top_area_face').click();
  }
}, false);